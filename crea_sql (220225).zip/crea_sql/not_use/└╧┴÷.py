#!/usr/bin/python3

import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding = 'utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding = 'utf-8')
print(
12월 4일
<li>제작을 결심
<li>내용구상
<li>시작이반이다.<p>
12월 5일
중앙정렬을 알아냄
선그리는법을 알아냄(border)
그리드를 배움
미디어쿼리?<P>
  12월6일
  자바스크립트시작됨
  조건문에 등호를 세개나 써야
  간단한 버튼 제작완료<p>
    12월7일
    함수랑 변수가 파이썬이랑 비슷한듯
    기껏 만들어놨더니 jquery라는 친구가 나옴
    ui와 api의 개념을 배움
    추천검색어--
    document, dom, window,ajax,cookie,offline web aplication,webRTC,speech,webGL,webVr
<p>html css javascript jquery로는 부족하다. 파이썬이나 php를 배워야한댄다.
12월12일
열이39도까지 뻗쳐서 며칠 안했더니 쓰기가 귀찮아짐
파이썬강좌를들으며 대규모공사중
)
