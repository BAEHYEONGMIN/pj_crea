package com.example.math;

import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Clicked extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_click);

    }

    public static class ReadData extends AppCompatActivity {
        String strtxt="";
        final static String TAG = "MainActivity";
        String urlAddr = "http://45.120.69.23/crea_sql/sql_to_json.py";
        TextView go_to_home;

        private RecyclerView mRecyclerView;
        private RecyclerView.Adapter mAdapter;
        private RecyclerView.LayoutManager mLayoutMangaer;
        private String[] mDataset = {"1", "2", "3", "4", "5"};
        private Spinner spinner_test;
        private String[] spinner_item;
        private EditText EditText_search;
        private String search_text = "";
        private ImageView ImageView_search_button;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.list_test);
            mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
            mRecyclerView.setHasFixedSize(true);
            mLayoutMangaer = new LinearLayoutManager(this);
            mRecyclerView.setLayoutManager(mLayoutMangaer);

            spinner_test = (Spinner)findViewById(R.id.spinner_test);
            spinner_item = getResources().getStringArray(R.array.spinner_test_list);
            ArrayAdapter<String> spinner_adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, spinner_item);
            spinner_test.setAdapter(spinner_adapter);
            spinner_test.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d("spinner", spinner_item[position]);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) { }
            });

            ImageView_search_button = findViewById(R.id.ImageView_search_button);
            ImageView_search_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    EditText_search = findViewById(R.id.EditText_search);
                    search_text = EditText_search.getText().toString();
                    Log.d("search_text" , search_text);
                }
            });

            Runnable r = new RequestThread();
            Thread thread = new Thread(r);
            Runnable r2 = new getstrtxt();
            Thread thread2 = new Thread(r2);
            try {
                thread.start();
                thread.join();
            }catch (InterruptedException e){}
            try {
                thread2.start();
                thread2.join();
            }catch (InterruptedException e){}


            go_to_home = findViewById(R.id.go_to_home);

            go_to_home.setClickable(true);
            go_to_home.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { finish(); }
            });
        }



        class RequestThread implements Runnable {
            public void run() {
                try {
                    Log.d("strtest","thread1");
                    URL url = new URL(urlAddr);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                    if (conn != null) {
                        conn.setConnectTimeout(10000); // 10초 대기 후 응답이 없으면 끝
                        conn.setRequestMethod("GET");
                        conn.setDoInput(true); // 서버에서 받기 가능
                        conn.setDoOutput(true); // 서버에 보내기 가능

                        int resCode = conn.getResponseCode(); // 서버에 연결 시도

                        // reader는 바이트 배열이 아니라, 문자열로 처리할 수 있음
                        // BufferedReader는 한줄씩 읽어들임
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        String line = null;

                        while (true) {
                            line = reader.readLine();
                            if (line == null) break;
    //
    //                        text_connect.append(line + "\n");
                            strtxt = strtxt + line;
                        }
                        reader.close();
                        conn.disconnect();

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

        }

    //    public void println(final String data) {
    //        handler2.post(new Runnable() {
    //            @Override
    //            public void run() {
    //
    //                text_connect.append(data + "\n");
    //                text_connect2.append(data);
    //                strtxt = strtxt + data;
    //                Log.d("strtxt", strtxt);
    //            }
    //        });
    //    }

        class getstrtxt implements Runnable{
            @Override
            public void run() {
                try {
                    JSONObject jsonObj = new JSONObject(strtxt);

                    JSONArray arrayaArticles = jsonObj.getJSONArray("articles");
                    Log.d("JSONLOG", arrayaArticles.toString());
                    List<NewsData> news = new ArrayList<>();

                    for (int i = 0, j = arrayaArticles.length(); i < j-1; i++) {
                        JSONObject obj = arrayaArticles.getJSONObject(i);


                        NewsData newsData = new NewsData();
                        newsData.setTitle(obj.getString("title"));
                        newsData.setText2(obj.getString("text2"));
                        newsData.setText1(obj.getString("text1"));
                        newsData.setDate(obj.getString("created"));
                        news.add(newsData);

                        //Log.d("news",news.toString() );

                    }
                    mAdapter = new MyAdapter(news);
                    mRecyclerView.setAdapter(mAdapter);
                    Log.d("mAdapter",mAdapter.toString() );
                } catch (JSONException e) {
                    e.printStackTrace();
                }Log.d("strtxt2", "end");

            }
        }

    }
}