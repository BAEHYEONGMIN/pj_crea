package com.example.math;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private List<NewsData> mDataset;

    public MyAdapter(List<NewsData> myDataset) {
        mDataset = myDataset;
    }


    // Create new views (invoked by the layout manager)
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view, which defines the UI of the list item
        LinearLayout view = (LinearLayout)LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.list_row, viewGroup, false);

        return new ViewHolder(view);
    }
    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {

        // Get element from your dataset at this position and replace the
        // contents of the view with that element
        NewsData news = mDataset.get(position);

        viewHolder.TextView_title.setText(news.getTitle());
        viewHolder.TextView_content.setText(news.getText1());
        viewHolder.Textview_name.setText(news.getText2());
        viewHolder.TextView_date.setText(news.getDate());
        viewHolder.ImageView_title.setImageResource(R.drawable.crea);
        viewHolder.cardview.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Log.d("cardview!",String.valueOf(position));
                Intent intent = new Intent(v.getContext(), Card.class);

                intent.putExtra("position",position);
                intent.putExtra("TextView_title",news.getTitle());
                intent.putExtra("TextView_content",news.getText1());
                intent.putExtra("Textview_name",news.getText2());
                intent.putExtra("TextView_date",news.getDate());

                v.getContext().startActivity(intent);
            }
        });


        Log.d("bindviewholder","finish");


    }
    public interface OnItemClickListener{
        void onItemClick(View v, int position);
    }
    private OnItemClickListener mListener = null;

    public void setOnItemClickListener(OnItemClickListener listener){
        this.mListener = listener;
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView TextView_title;
        private TextView TextView_content;
        private ImageView ImageView_title;
        private TextView TextView_date;
        private TextView Textview_name;
        private CardView cardview;
        public ViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if(pos != RecyclerView.NO_POSITION){
                        //123
                        Log.d("recyclerview!",String.valueOf(pos));
                    }
                }
            });
            TextView_title = itemView.findViewById(R.id.list_title);
            TextView_content = itemView.findViewById(R.id.list_content);
            Textview_name = itemView.findViewById(R.id.list_name);
            ImageView_title = itemView.findViewById(R.id.list_image);
            TextView_date = itemView.findViewById(R.id.list_date);
            cardview = itemView.findViewById(R.id.card_view);
        }


    }



}
