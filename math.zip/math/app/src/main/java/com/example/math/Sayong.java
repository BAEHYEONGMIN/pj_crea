package com.example.math;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Sayong extends AppCompatActivity {
    TextView sayong_submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sayong);

        sayong_submit = findViewById(R.id.sayong_submit);

        sayong_submit.setClickable(true);
        sayong_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}