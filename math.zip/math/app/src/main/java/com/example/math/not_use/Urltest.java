package com.example.math.not_use;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.os.StrictMode;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Size;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.math.R;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Urltest extends AppCompatActivity {
    TextView write_submit;
    ImageView math_image;
    TextView button_photo;
    Uri selectedImageUri;
    private final int GET_GALLERY_IMAGE = 200;
    String imgstr[];
    int imgstr_size;
    String imgstr_size_str;
    String strurl = "http://gphscrea.ga/crea_sql/not_use/urltestimage.py";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.urlwrite);


        write_submit = findViewById(R.id.write_submit);
        write_submit.setClickable(true);
        write_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String, String> data = new HashMap<String, String>();
                new Thread() {
                    public void run() {

                        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
                        Resources res = getResources();

                        BitmapDrawable drawable = (BitmapDrawable) math_image.getDrawable();
                        Bitmap bitmap = drawable.getBitmap();

                        bitmap.compress(Bitmap.CompressFormat.JPEG, 10, outStream);
                        byte[] image = outStream.toByteArray();
                        String profileImageBase64 = Base64.encodeToString(image, 0);


                        Log.d("base64", String.valueOf(profileImageBase64.length()));
                        imgstr_size = profileImageBase64.length() / 2000;
                        Log.d("size", imgstr_size_str.valueOf(imgstr_size));
                        imgstr = new String[imgstr_size+1];
                        HashMap<String,String> data = new HashMap<String,String>();
                        for (int i = 0; i < imgstr_size+1; i++) {

                            if (i == imgstr_size) {
                                imgstr[i] = profileImageBase64.substring(i*2000);
                            } else {
                                imgstr[i] = profileImageBase64.substring(i * 2000, (i + 1) * 2000);
                            }
                            data.put("key",imgstr[i]);
                            Log.d("asdf",imgstr[i]);
                        }
                    }

                }.start();
            }


        });

        math_image = (ImageView)

                findViewById(R.id.math_image);

        button_photo = (TextView)

                findViewById(R.id.button_photo);
        button_photo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setDataAndType(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                startActivityForResult(intent, GET_GALLERY_IMAGE);
            }
        });
    }

    private String send(HashMap<String, String> map, String addr) {
        String response = ""; // DB 서버의 응답을 담는 변수

        try {
            Log.d("Log123", "log");
            URL url = new URL(addr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection(); // 해당 URL에 연결

            conn.setConnectTimeout(10000); // 타임아웃: 10초
            conn.setUseCaches(false); // 캐시 사용 안 함
            conn.setRequestMethod("POST"); // POST로 연결
            conn.setDoInput(true);
            conn.setDoOutput(true);

            if (map != null) { // 웹 서버로 보낼 매개변수가 있는 경우우
                OutputStream os = conn.getOutputStream(); // 서버로 보내기 위한 출력 스트림
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os, "UTF-8")); // UTF-8로 전송
                bw.write(getPostString(map)); // 매개변수 전송
                bw.flush();
                bw.close();
                os.close();
            }

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) { // 연결에 성공한 경우
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream())); // 서버의 응답을 읽기 위한 입력 스트림

                while ((line = br.readLine()) != null) // 서버의 응답을 읽어옴
                    response += line;
            }

            conn.disconnect();
        } catch (MalformedURLException me) {
            me.printStackTrace();
            return me.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }
        return response;
    }

    private String getPostString(HashMap<String, String> map) {
        StringBuilder result = new StringBuilder();
        boolean first = true; // 첫 번째 매개변수 여부

        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (first)
                first = false;
            else // 첫 번째 매개변수가 아닌 경우엔 앞에 &를 붙임
                result.append("&");

            try { // UTF-8로 주소에 키와 값을 붙임
                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
                Log.d("LOG345", result.toString());
            } catch (UnsupportedEncodingException ue) {
                ue.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return result.toString();
    }

    public String getBase64String(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);

        byte[] imageBytes = byteArrayOutputStream.toByteArray();

        return Base64.encodeToString(imageBytes, Base64.NO_WRAP);
    }

//
//    void imageUpload(final String filename, String stidx) {
//        String urlString = "http://gphscrea.ga/crea_sql/not_use/urltesimaget.py";
//
//        String lineEnd = "\r\n";
//        String twoHyphens = "--";
//        String boundary = "*****";
//
//        try {
//            FileInputStream mFileInputStream = new FileInputStream(filename);
//
//            URL connectUrl = new URL(urlString);
//            Log.d("Test", "mFileInputStream  is " + mFileInputStream);
//
//            // open connection
//            HttpURLConnection con = (HttpURLConnection) connectUrl.openConnection();
//            con.setDoInput(true);
//            con.setDoOutput(true);
//            con.setUseCaches(false);
//            con.setRequestMethod("POST");
//            con.setRequestProperty("Connection", "Keep-Alive");
//            con.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
//
//            // write data
//            DataOutputStream dos = new DataOutputStream(con.getOutputStream());
//            dos.writeBytes(twoHyphens + boundary + lineEnd);
//            dos.writeBytes("Content-Disposition: form-data; name=\"stidx\"\r\n\r\n" + stidx + lineEnd);
//            dos.writeBytes(twoHyphens + boundary + lineEnd);
//            dos.writeBytes("Content-Disposition: form-data; name=\"uploadedfile\";image=\"" + filename + "\"" + lineEnd);
//            dos.writeBytes("Content-Type: application/octet-stream\r\n\r\n");
//
//            int bytesAvailable = mFileInputStream.available();
//            int maxBufferSize = 1024;
//            int bufferSize = Math.min(bytesAvailable, maxBufferSize);
//
//            byte[] buffer = new byte[bufferSize];
//            int bytesRead = mFileInputStream.read(buffer, 0, bufferSize);
//
//            Log.d("Test", "image byte is " + bytesRead);
//
//            // read image
//            while (bytesRead > 0) {
//                dos.write(buffer, 0, bufferSize);
//                bytesAvailable = mFileInputStream.available();
//                bufferSize = Math.min(bytesAvailable, maxBufferSize);
//                bytesRead = mFileInputStream.read(buffer, 0, bufferSize);
//            }
//
//            dos.writeBytes(lineEnd);
//            dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
//
//            // close streams
//            Log.e("Test", "File is written");
//            mFileInputStream.close();
//            dos.flush(); // finish upload...
//
//            // get response
//            int ch;
//            InputStream is = con.getInputStream();
//            StringBuffer b = new StringBuffer();
//            while ((ch = is.read()) != -1) {
//                b.append((char) ch);
//            }
//            String s = b.toString();
//            Log.e("Test", "result = " + s);
//            dos.close();
//
//
//        } catch (Exception e) {
//            Log.d("Test", "exception " + e.getMessage());
//            // TODO: handle exception
//        }
//    }


//    public void post(Uri UriUri){
//        try{
//            Uri uri = UriUri;
//            URL url = new URL(strurl);
//
//            String boundary = "SpecificString";
//
//            URLConnection con = url.openConnection();
//
//            con.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
//
//            con.setDoOutput(true);
//            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
//
//            wr.writeBytes("\r\n--" + boundary + "\r\n");
//
//            wr.writeBytes("Content-Disposition: form-data; name=\"image\"; filename=\"image.jpg\"\r\n");
//
//            wr.writeBytes("Content-Type: application/octet-stream\r\n\r\n");
//
//            FileInputStream fileInputStream = new FileInputStream(getRealPathFromURI(uri));
//
//            int bytesAvailable = fileInputStream.available();
//
//            int maxBufferSize = 1024;
//
//            int bufferSize = Math.min(bytesAvailable, maxBufferSize);
//
//            byte[] buffer = new byte[bufferSize];
//
//
//            int bytesRead = fileInputStream.read(buffer, 0, bufferSize);
//
//            while (bytesRead > 0) {
//
//// Upload file part(s)
//
//                DataOutputStream dataWrite = new DataOutputStream(con.getOutputStream());
//
//                dataWrite.write(buffer, 0, bufferSize);
//
//                bytesAvailable = fileInputStream.available();
//
//                bufferSize = Math.min(bytesAvailable, maxBufferSize);
//
//                bytesRead = fileInputStream.read(buffer, 0, bufferSize);
//
//            }
//
//            fileInputStream.close();
//            wr.writeBytes("\r\n--" + boundary + "--\r\n");
//
//            wr.flush();
//        }catch (Exception e){}
//    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == GET_GALLERY_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {

            selectedImageUri = data.getData();
            math_image.setImageURI(selectedImageUri);

        }
    }
//
//    /////   Uri 에서 파일명을 추출하는 로직
//    public String getImageNameToUri(Uri data) {
//        String[] proj = {MediaStore.Images.Media.DATA};
//        Cursor cursor = managedQuery(data, proj, null, null, null);
//        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
//
//        cursor.moveToFirst();
//
//        String imgPath = cursor.getString(column_index);
//        String imgName = imgPath.substring(imgPath.lastIndexOf("/") + 1);
//
//        return imgName;
//    }
//

//    public String getRealPathFromURI(Uri contentUri) {
//
//        String[] proj = {MediaStore.Images.Media.DATA};
//
//        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
//        cursor.moveToNext();
//        String path = cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.DATA));
//        Uri uri = Uri.fromFile(new File(path));
//
//        cursor.close();
//        return path;
//    }


//
//    private String send(HashMap<String, String> map, String addr) {
//        String response = ""; // DB 서버의 응답을 담는 변수
//
//        try {
//            Log.d("log","log");
//            URL url = new URL(addr);
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection(); // 해당 URL에 연결
//
//            conn.setConnectTimeout(10000); // 타임아웃: 10초
//            conn.setUseCaches(false); // 캐시 사용 안 함
//            conn.setRequestMethod("POST"); // POST로 연결
//            conn.setDoInput(true);
//            conn.setDoOutput(true);
//
//            if (map != null) { // 웹 서버로 보낼 매개변수가 있는 경우우
//                OutputStream os = conn.getOutputStream(); // 서버로 보내기 위한 출력 스트림
//                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os, "UTF-8")); // UTF-8로 전송
//                bw.write(getPostString(map)); // 매개변수 전송
//                bw.flush();
//                bw.close();
//                os.close();
//            }
//
//            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) { // 연결에 성공한 경우
//                String line;
//                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream())); // 서버의 응답을 읽기 위한 입력 스트림
//
//                while ((line = br.readLine()) != null) // 서버의 응답을 읽어옴
//                    response += line;
//            }
//
//            conn.disconnect();
//        } catch (MalformedURLException me) {
//            me.printStackTrace();
//            return me.toString();
//        } catch (Exception e) {
//            e.printStackTrace();
//            return e.toString();
//        }
//        return response;
//    }
//
//    // 매개변수를 URL에 붙이는 함수
//// 참고: http://stackoverflow.com/questions/9767952/how-to-add-parameters-to-httpurlconnection-using-post
//    private String getPostString(HashMap<String, String> map) {
//        StringBuilder result = new StringBuilder();
//        boolean first = true; // 첫 번째 매개변수 여부
//
//        for (Map.Entry<String, String> entry : map.entrySet()) {
//            if (first)
//                first = false;
//            else // 첫 번째 매개변수가 아닌 경우엔 앞에 &를 붙임
//                result.append("&");
//
//            try { // UTF-8로 주소에 키와 값을 붙임
//                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
//                result.append("=");
//                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
//                Log.d("log",result.toString());
//            } catch (UnsupportedEncodingException ue) {
//                ue.printStackTrace();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//
//        return result.toString();
//    }

//    public void connect(){
//        try {
//            Log.d("log","hi");
//            URL url = new URL(strurl);
//            // HttpURLConnection 객체 생성.
//            HttpURLConnection conn = null;
//
//// URL 연결 (웹페이지 URL 연결.)
//            conn = (HttpURLConnection) url.openConnection();
//
//// TimeOut 시간 (서버 접속시 연결 시간)
//            conn.setConnectTimeout(10000);
//
//// TimeOut 시간 (Read시 연결 시간)
//            conn.setReadTimeout(10000);
//
//// 요청 방식 선택 (GET, POST)
//            conn.setRequestMethod("POST");
//
//// Request Header값 셋팅 setRequestProperty(String key, String value)
//            conn.setRequestProperty("title", "1");
//            conn.setRequestProperty("content", "2");
//
//
//            conn.setRequestProperty("content-type", "application/x-www-form-urlencoded");
//
//// 컨트롤 캐쉬 설정
//            conn.setRequestProperty("Cache-Control", "no-cache");
//
//// 타입길이 설정(Request Body 전달시 Data Type의 길이를 정함.)
//            conn.setRequestProperty("Content-Length", "length");
//
//// User-Agent 값 설정
//            conn.setRequestProperty("User-Agent", "test");
//
//// OutputStream으로 POST 데이터를 넘겨주겠다는 옵션.
//            conn.setDoOutput(true);
//
//// InputStream으로 서버로 부터 응답을 받겠다는 옵션.
//            conn.setDoInput(true);
//
//// Request Body에 Data를 담기위해 OutputStream 객체를 생성.
//            OutputStream os = conn.getOutputStream();
//
//
//// Request Body에 Data 입력.
//            os.flush();
//
//// OutputStream 종료.
//            os.close();
//
//// 실제 서버로 Request 요청 하는 부분. (응답 코드를 받는다. 200 성공, 나머지 에러)
//            int responseCode = conn.getResponseCode();
//
//// 접속해지
//            conn.disconnect();
//        }catch (Exception e){}
//    }

//    public class HttpConnectionUtil {
//        public String postRequest(String pURL, HashMap < String, String > pList) {
//
//            String myResult = "";
//
//            try {
//                //   URL 설정하고 접속하기
//                URL url = new URL(pURL); // URL 설정
//
//                HttpURLConnection http = (HttpURLConnection) url.openConnection(); // 접속
//                //--------------------------
//                //   전송 모드 설정 - 기본적인 설정
//                //--------------------------
//                http.setDefaultUseCaches(false);
//                http.setDoInput(true); // 서버에서 읽기 모드 지정
//                http.setDoOutput(true); // 서버로 쓰기 모드 지정
//                http.setRequestMethod("POST"); // 전송 방식은 POST
//
//
//
//                //--------------------------
//                // 헤더 세팅
//                //--------------------------
//                // 서버에게 웹에서 <Form>으로 값이 넘어온 것과 같은 방식으로 처리하라는 걸 알려준다
//                http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
//
//
//                //--------------------------
//                //   서버로 값 전송
//                //--------------------------
//                StringBuffer buffer = new StringBuffer();
//
//                //HashMap으로 전달받은 파라미터가 null이 아닌경우 버퍼에 넣어준다
//                if (pList != null) {
//
//                    Set key = pList.keySet();
//
//                    for (Iterator iterator = key.iterator(); iterator.hasNext();) {
//                        String keyName = (String) iterator.next();
//                        String valueName = pList.get(keyName);
//                        buffer.append(keyName).append("=").append(valueName);
//                    }
//                }
//
//                OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
//                PrintWriter writer = new PrintWriter(outStream);
//                writer.write(buffer.toString());
//                writer.flush();
//
//
//                //--------------------------
//                //   Response Code
//                //--------------------------
//                //http.getResponseCode();
//
//
//                //--------------------------
//                //   서버에서 전송받기
//                //--------------------------
//                InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
//                BufferedReader reader = new BufferedReader(tmp);
//                StringBuilder builder = new StringBuilder();
//                String str;
//                while ((str = reader.readLine()) != null) {
//                    builder.append(str + "\n");
//                }
//                myResult = builder.toString();
//                return myResult;
//
//            } catch (MalformedURLException e) {
//                e.printStackTrace();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            return myResult;
//        }
//
//    }
}