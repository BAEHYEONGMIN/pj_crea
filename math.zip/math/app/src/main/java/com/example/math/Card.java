package com.example.math;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Card extends AppCompatActivity {
    private Intent intent;

    private TextView TextView_title;
    private TextView TextView_content;
    private ImageView ImageView_title;
    private TextView TextView_date;
    private TextView Textview_name;
    private TextView go_to_home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
        setContentView(R.layout.list_click);
        TextView_title = findViewById(R.id.list_title);
        TextView_content = findViewById(R.id.list_content);
        TextView_content.setMovementMethod(new ScrollingMovementMethod());
        TextView_date = findViewById(R.id.list_date);
        Textview_name = findViewById(R.id.list_name);
        ImageView_title = findViewById(R.id.list_image);

        intent = getIntent();
        TextView_title.setText(intent.getStringExtra("TextView_title"));
        TextView_content.setText(intent.getStringExtra("TextView_content"));
        TextView_content.setTextIsSelectable(true);
        TextView_date.setText(intent.getStringExtra("TextView_date"));
        Textview_name.setText(intent.getStringExtra("Textview_name"));
        ImageView_title.setImageResource(R.drawable.crea);

        go_to_home = findViewById(R.id.go_to_home);

        go_to_home.setClickable(true);
        go_to_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { finish(); }
        });

    }
}
