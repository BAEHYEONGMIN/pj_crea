package com.example.math;

import java.io.Serializable;

public class NewsData implements Serializable {
    private String title;
    private String text1;
    private String text2;
    private String date;



    public String toString(){
        return "\n" + "title : " + title + "\ntext1 : " + text1 + "\nrating : " + text2 + "\n";
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }

    public String getText2() {
        return text2;
    }

    public void setText2(String text2) {
        this.text2 = text2;
    }


    public String getDate() {return date;}

    public void setDate(String date) {this.date = date;}
}
