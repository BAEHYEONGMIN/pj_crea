package com.example.math;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    LinearLayout button_write;
    LinearLayout button_read;
    TextView button_sayong;
    TextView button_crea;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button_write = findViewById(R.id.button_write);
        button_write.setClickable(true);
        button_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Write.class);
                startActivity(intent);
            }

        });
        button_read = findViewById(R.id.button_read);
        button_read.setClickable(true);
        button_read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Clicked.ReadData.class);
                startActivity(intent);
            }
        });
        button_sayong = findViewById(R.id.button_sayong);
        button_sayong.setClickable(true);
        button_sayong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Sayong.class);
                startActivity(intent);
            }
        });
        button_crea = findViewById(R.id.button_crea);
        button_crea.setClickable(true);
        button_crea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Crea.class);
                startActivity(intent);
            }
        });




    }

}