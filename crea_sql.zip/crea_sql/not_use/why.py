#!/usr/bin/python3
print("content-type:text/html; charset=UTF-8\n")
print(1+1)

